---
title: DailyUIのデザインチャレンジ
summary: 百日間に一日のデザインチャレンジです。
  
tags:
# - Deep Learning
date: "2022"

# Optional external URL for project (replaces project detail page).
external_link: ""

image:
  caption: 
  focal_point: Smart

links:
# - icon: figma
#   icon_pack: fab
#   name: Link to Figma prototype
#   url: https://www.figma.com/proto/Bm5bpQRGBaoI9DWLHyEodo/Laundy?page-id=1%3A211&node-id=62%3A230&viewport=581%2C569%2C0.28126800060272217&scaling=scale-down
url_code: ""
url_pdf: ""
url_slides: ""
url_video: ""

# Slides (optional).
#   Associate this project with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides = "example-slides"` references `content/slides/example-slides.md`.
#   Otherwise, set `slides = ""`.
slides: ""
---

#### 1日 - サインアップ

![DailyUI１日にのデザイン](/portfolio/DailyUI/Day001.png)

#### 2日 -  クレジットカードレジ

![DailyUIの2日のデザイン](/portfolio/DailyUI/Day002.png)

#### 3日 - ランディングページ

![DailyUIの3日のデザイン](/portfolio/DailyUI/Day003.png)

#### 4日 - 電卓

![DailyUIの4日のデザイン](/portfolio/DailyUI/Day004.png)

#### 5日 - アプリのアイコン

![DailyUIの5日のデザイン](/portfolio/DailyUI/Day005.png)

##### 6日 - プロファイル

![DailyUIの6日のデザイン](/portfolio/DailyUI/Day006.png)

##### 7日 - 設定

![DailyUIの7日のデザイン](/portfolio/DailyUI/Day007.png)