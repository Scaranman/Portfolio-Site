---
widget: Google-Drive-Embed

# This file represents a page section.
headless: true

# Order that this section appears on the page.
weight: 35

#Change the Section title to your liking
title: 履歴書

#put the link to your google drive file. Replace "view?usp=sharing" with "preview".
link: https://drive.google.com/file/d/1cBHSoWWyASvaxLZHZK8fkAdE6qXN5FX1/preview

#set the height and width for the iframe (examples: "800px", "100%", etc)
height: 75vh

author: admin
---

{{< icon name="download" pack="fas" >}}{{< staticref "media/JA/JACOB SCARANI RESUME.pdf" "newtab" >}}ダウンロード{{< /staticref >}}
