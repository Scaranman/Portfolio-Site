---
widget: Google-Drive-Embed

# This file represents a page section.
headless: true

# Order that this section appears on the page.
weight: 35

#Change the Section title to your liking
title: Resume

# put the link to your google drive file. Replace "view?usp=sharing" with "preview".
link: https://drive.google.com/file/d/101RBVx9u-hMInrTmDgdPGe3XahKxLwpz/preview

height: 75vh

author: admin
---

{{< icon name="download" pack="fas" >}}{{< staticref "media/JACOB SCARANI RESUME.pdf" "newtab" >}}Download{{< /staticref >}}

*This resume is in US letter format